<footer class="footer">

   &copy; copyright @ <?= date('Y'); ?> by <span>Sigma Team</span> | all rights reserved!

</footer>